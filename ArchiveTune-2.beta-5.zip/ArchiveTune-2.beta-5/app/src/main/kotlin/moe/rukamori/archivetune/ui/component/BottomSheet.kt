/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package moe.rukamori.archivetune.ui.component

import android.view.View
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.DraggableState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.rukamori.archivetune.LocalAnimationsDisabled
import moe.rukamori.archivetune.constants.BottomSheetAnimationSpec
import moe.rukamori.archivetune.constants.BottomSheetSoftAnimationSpec
import moe.rukamori.archivetune.constants.NavigationBarAnimationSpec

/**
 * Bottom Sheet
 * Modified from [ViMusic](https://github.com/vfsfitvnm/ViMusic)
 */
@Composable
fun BottomSheet(
    state: BottomSheetState,
    modifier: Modifier = Modifier,
    backgroundColor: Color,
    onDismiss: (() -> Unit)? = null,
    onCollapsedContentClick: (() -> Unit)? = null,
    backHandlerEnabled: Boolean = true,
    collapsedContent: @Composable BoxScope.() -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .offset {
                    val y =
                        (state.expandedBound - state.value)
                            .roundToPx()
                            .coerceAtLeast(0)
                    IntOffset(x = 0, y = y)
                }.bottomSheetDraggable(state, onDismiss)
                .clip(
                    RoundedCornerShape(
                        topStart = if (!state.isExpanded) 16.dp else 0.dp,
                        topEnd = if (!state.isExpanded) 16.dp else 0.dp,
                    ),
                ).background(
                    backgroundColor.copy(
                        alpha = backgroundColor.alpha * state.progress.coerceIn(0f, 1f),
                    ),
                ),
    ) {
        if (state.isExpandedOrExpanding && backHandlerEnabled) {
            BackHandler(onBack = state::collapseSoft)
        }

        if (!state.isCollapsed) {
            BoxWithConstraints(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            alpha = ((state.progress - 0.25f) * 4).coerceIn(0f, 1f)
                        },
                content = content,
            )
        }

        if (!state.isExpanded && (onDismiss == null || !state.isDismissed)) {
            Box(
                modifier =
                    Modifier
                        .graphicsLayer {
                            alpha = 1f - (state.progress * 4).coerceAtMost(1f)
                        }.clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onCollapsedContentClick ?: state::expandSoft,
                        ).fillMaxWidth()
                        .height(state.collapsedBound),
                content = collapsedContent,
            )
        }
    }
}

@Stable
class BottomSheetState(
    draggableState: DraggableState,
    private val coroutineScope: CoroutineScope,
    private val animatable: Animatable<Dp, AnimationVector1D>,
    private val onAnchorChanged: (Int) -> Unit,
    private val animationsDisabled: Boolean,
    collapsedBound: Dp,
    initialAnchor: Int = DISMISSED_ANCHOR,
) : DraggableState by draggableState {
    private val collapsedBoundState = mutableStateOf(collapsedBound)

    val collapsedBound: Dp
        get() = collapsedBoundState.value

    internal var targetCollapsedBound: Dp by mutableStateOf(
        collapsedBound.coerceIn(animatable.lowerBound!!, animatable.upperBound!!)
    )
        private set

    private var lastAnimationSpec: AnimationSpec<Dp> =
        if (animationsDisabled) snap() else BottomSheetAnimationSpec

    internal fun updateTargetCollapsedBound(newTargetBound: Dp) {
        val clampedTarget = newTargetBound.coerceIn(animatable.lowerBound!!, animatable.upperBound!!)
        val previousTarget = targetCollapsedBound
        targetCollapsedBound = clampedTarget
        if (previousTarget == clampedTarget) return

        if (targetAnchor == COLLAPSED_ANCHOR) {
            val isRestingAtOldCollapsed = !animatable.isRunning &&
                (animatable.value - collapsedBoundState.value).let { if (it < 0.dp) -it else it } < 0.5.dp
            if (!isRestingAtOldCollapsed) {
                coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
                    animatable.animateTo(clampedTarget, lastAnimationSpec)
                }
            }
        }
    }

    internal suspend fun reanchorTo(newCollapsedBound: Dp) {
        val previous = collapsedBoundState.value
        if (newCollapsedBound == previous) return
        val current = animatable.value
        val isRestingAtCollapsed = !animatable.isRunning &&
            (current == previous || (current - previous).let { if (it < 0.dp) -it else it } < 0.5.dp)

        val target =
            if (isRestingAtCollapsed) {
                newCollapsedBound.coerceIn(
                    animatable.lowerBound!!,
                    animatable.upperBound!!,
                )
            } else {
                current
            }

        withContext(NonCancellable) {
            if (target != current) {
                animatable.snapTo(target)
            }
            collapsedBoundState.value = newCollapsedBound
        }
    }

    val dismissedBound: Dp
        get() = animatable.lowerBound!!

    val expandedBound: Dp
        get() = animatable.upperBound!!

    val value by animatable.asState()

    var targetAnchor by mutableIntStateOf(initialAnchor)
        private set

    val isDismissed by derivedStateOf {
        value == animatable.lowerBound!!
    }

    val isCollapsed by derivedStateOf {
        value == collapsedBound
    }

    val isExpanded by derivedStateOf {
        value == animatable.upperBound
    }

    val isExpandedOrExpanding: Boolean
        get() = targetAnchor == EXPANDED_ANCHOR

    val progress by derivedStateOf {
        1f - (animatable.upperBound!! - animatable.value) / (animatable.upperBound!! - collapsedBound)
    }

    private fun updateAnchor(anchor: Int) {
        targetAnchor = anchor
        onAnchorChanged(anchor)
    }

    fun collapse(animationSpec: AnimationSpec<Dp>) {
        updateAnchor(COLLAPSED_ANCHOR)
        lastAnimationSpec = animationSpec
        coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
            animatable.animateTo(targetCollapsedBound, animationSpec)
        }
    }

    fun expand(animationSpec: AnimationSpec<Dp>) {
        updateAnchor(EXPANDED_ANCHOR)
        lastAnimationSpec = animationSpec
        coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
            animatable.animateTo(animatable.upperBound!!, animationSpec)
        }
    }

    private fun collapse() {
        collapse(if (animationsDisabled) snap() else BottomSheetAnimationSpec)
    }

    private fun expand() {
        expand(if (animationsDisabled) snap() else BottomSheetAnimationSpec)
    }

    fun collapseSoft() {
        collapse(if (animationsDisabled) snap() else BottomSheetSoftAnimationSpec)
    }

    fun expandSoft() {
        expand(if (animationsDisabled) snap() else BottomSheetSoftAnimationSpec)
    }

    fun dismiss() {
        updateAnchor(DISMISSED_ANCHOR)
        val spec = if (animationsDisabled) snap() else BottomSheetAnimationSpec
        lastAnimationSpec = spec
        coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
            animatable.animateTo(animatable.lowerBound!!, spec)
        }
    }

    fun snapTo(value: Dp) {
        updateAnchor(
            when (value) {
                expandedBound -> EXPANDED_ANCHOR
                collapsedBound -> COLLAPSED_ANCHOR
                dismissedBound -> DISMISSED_ANCHOR
                else -> COLLAPSED_ANCHOR
            },
        )
        coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
            animatable.snapTo(value)
        }
    }

    fun performFling(
        velocity: Float,
        onDismiss: (() -> Unit)?,
    ) {
        if (velocity > 250) {
            expand()
        } else if (velocity < -250) {
            if (value < collapsedBound && onDismiss != null) {
                dismiss()
                onDismiss.invoke()
            } else {
                collapse()
            }
        } else {
            val l0 = dismissedBound
            val l1 = (collapsedBound - dismissedBound) / 2
            val l2 = (expandedBound - collapsedBound) / 2
            val l3 = expandedBound

            when (value) {
                in l0..l1 -> {
                    if (onDismiss != null) {
                        dismiss()
                        onDismiss.invoke()
                    } else {
                        collapse()
                    }
                }

                in l1..l2 -> {
                    collapse()
                }

                in l2..l3 -> {
                    expand()
                }

                else -> {
                    Unit
                }
            }
        }
    }

    val preUpPostDownNestedScrollConnection
        get() =
            object : NestedScrollConnection {
                var isTopReached = false

                override fun onPreScroll(
                    available: Offset,
                    source: NestedScrollSource,
                ): Offset {
                    if (isExpanded && available.y < 0) {
                        isTopReached = false
                    }

                    return if (isTopReached && available.y < 0 && source == NestedScrollSource.UserInput) {
                        dispatchRawDelta(available.y)
                        available
                    } else {
                        Offset.Zero
                    }
                }

                override fun onPostScroll(
                    consumed: Offset,
                    available: Offset,
                    source: NestedScrollSource,
                ): Offset {
                    if (!isTopReached) {
                        isTopReached = consumed.y == 0f && available.y > 0
                    }

                    return if (isTopReached && source == NestedScrollSource.UserInput) {
                        dispatchRawDelta(available.y)
                        available
                    } else {
                        Offset.Zero
                    }
                }

                override suspend fun onPreFling(available: Velocity): Velocity =
                    if (isTopReached) {
                        val velocity = -available.y
                        performFling(velocity, null)

                        available
                    } else {
                        Velocity.Zero
                    }

                override suspend fun onPostFling(
                    consumed: Velocity,
                    available: Velocity,
                ): Velocity {
                    isTopReached = false
                    return Velocity.Zero
                }
            }
}

const val EXPANDED_ANCHOR = 2
const val COLLAPSED_ANCHOR = 1
const val DISMISSED_ANCHOR = 0

@Composable
fun rememberBottomSheetState(
    dismissedBound: Dp,
    expandedBound: Dp,
    collapsedBound: Dp = dismissedBound,
    initialAnchor: Int = DISMISSED_ANCHOR,
): BottomSheetState {
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()
    val animationsDisabled = LocalAnimationsDisabled.current

    var previousAnchor by rememberSaveable {
        mutableIntStateOf(initialAnchor)
    }
    val animatable =
        remember {
            Animatable(0.dp, Dp.VectorConverter)
        }

    val state =
        remember(dismissedBound, expandedBound, coroutineScope, animationsDisabled) {
            val initialValue =
                when (previousAnchor) {
                    EXPANDED_ANCHOR -> expandedBound
                    COLLAPSED_ANCHOR -> collapsedBound
                    DISMISSED_ANCHOR -> dismissedBound
                    else -> error("Unknown BottomSheet anchor")
                }

            animatable.updateBounds(dismissedBound.coerceAtMost(expandedBound), expandedBound)
            coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
                animatable.animateTo(initialValue, if (animationsDisabled) snap() else BottomSheetAnimationSpec)
            }

            BottomSheetState(
                draggableState =
                    DraggableState { delta ->
                        coroutineScope.launch(start = CoroutineStart.UNDISPATCHED) {
                            animatable.snapTo(animatable.value - with(density) { delta.toDp() })
                        }
                    },
                onAnchorChanged = { previousAnchor = it },
                coroutineScope = coroutineScope,
                animatable = animatable,
                animationsDisabled = animationsDisabled,
                collapsedBound = collapsedBound,
                initialAnchor = previousAnchor,
            )
        }

    LaunchedEffect(state, collapsedBound) {
        state.updateTargetCollapsedBound(collapsedBound)
    }

    val animationSpec = if (animationsDisabled) snap() else NavigationBarAnimationSpec
    val animatedCollapsedBound by
        animateDpAsState(
            targetValue = collapsedBound,
            animationSpec = animationSpec,
            label = "SheetCollapsedBound",
        )
    LaunchedEffect(state) {
        snapshotFlow { animatedCollapsedBound }.collect {
            state.reanchorTo(it)
        }
    }

    return state
}

private class BottomSheetGestureRegion(private val view: View) {
    var coordinates: LayoutCoordinates? = null
    private val windowLocation = IntArray(2)

    fun canStartDrag(position: Offset): Boolean {
        val layoutCoordinates = coordinates?.takeIf { it.isAttached } ?: return false
        val insets = ViewCompat.getRootWindowInsets(view)?.getInsets(
            WindowInsetsCompat.Type.systemGestures() or WindowInsetsCompat.Type.navigationBars(),
        ) ?: return true
        val rootView = view.rootView
        rootView.getLocationInWindow(windowLocation)
        val windowPosition = layoutCoordinates.localToWindow(position)
        val x = windowPosition.x - windowLocation[0]
        val y = windowPosition.y - windowLocation[1]
        return x >= insets.left && x < rootView.width - insets.right &&
            y >= insets.top && y < rootView.height - insets.bottom
    }
}

@Composable
fun Modifier.bottomSheetDraggable(
    state: BottomSheetState,
    onDismiss: (() -> Unit)? = null,
): Modifier {
    val view = LocalView.current
    val gestureRegion = remember(view) { BottomSheetGestureRegion(view) }
    val updateCoordinates: (LayoutCoordinates) -> Unit = remember(gestureRegion) {
        { gestureRegion.coordinates = it }
    }
    val currentOnDismiss by rememberUpdatedState(onDismiss)

    return this
        .onGloballyPositioned(updateCoordinates)
        .pointerInput(state, gestureRegion) {
            val velocityTracker = VelocityTracker()

            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                if (!gestureRegion.canStartDrag(down.position)) return@awaitEachGesture

                val initialAnchor = state.targetAnchor
                velocityTracker.resetTracking()
                velocityTracker.addPointerInputChange(down)
                var dragStarted = false
                var dragCompleted = false

                try {
                    val drag = awaitVerticalTouchSlopOrCancellation(down.id) { change, overSlop ->
                        change.consume()
                        dragStarted = true
                        velocityTracker.addPointerInputChange(change)
                        state.dispatchRawDelta(overSlop)
                    } ?: return@awaitEachGesture

                    dragCompleted = verticalDrag(drag.id) { change ->
                        velocityTracker.addPointerInputChange(change)
                        state.dispatchRawDelta(change.positionChange().y)
                        change.consume()
                    }
                    if (dragCompleted) {
                        state.performFling(-velocityTracker.calculateVelocity().y, currentOnDismiss)
                    }
                } finally {
                    velocityTracker.resetTracking()
                    if (dragStarted && !dragCompleted) {
                        when (initialAnchor) {
                            EXPANDED_ANCHOR -> state.expandSoft()
                            COLLAPSED_ANCHOR -> state.collapseSoft()
                            DISMISSED_ANCHOR -> state.dismiss()
                        }
                    }
                }
            }
        }
}
